function myBirthYearFunc(){
        console.log("Nací en " + 1980);
    }
    // el console.log imprime el naci en 1980

    function myBirthYearFunc(EntradaAñoNacimiento){
            console.log("Nací en " + EntradaAñoNacimiento);
        }
// el console.log muesta naci en Entrada año nacimiento

